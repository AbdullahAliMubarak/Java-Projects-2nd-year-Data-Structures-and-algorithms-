select * from offices
where addressline2 is not NULL and
state is null;