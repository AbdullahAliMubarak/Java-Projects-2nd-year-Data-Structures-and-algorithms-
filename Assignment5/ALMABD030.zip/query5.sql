select productVendor, productCode, quantityInStock * 2 AS newStock
from products
where productVendor like 'Ex%to%';